espaceのテンプレートをダウンロードいただきまして
ありがとうございます(*・ω・*)

espaceのテンプレートは、利用規約の範囲内で無料でご利用いただけます。
サイト内の利用規約を必ずご確認ください。
利用規約は予告なく変更になる場合がございます。
変更した場合はTwitterやサイトのお知らせでご報告いたします。

espaceのTwitterでは最新情報をいち早くご確認いただけますので、
よろしければフォローをお願いいたします*

また、Twitter・マシュマロ・サイト内のメールフォームより
感想、コメントなどいただけますと大変励みになります<(_ _)>

今後もespaceをよろしくお願いいたします。

*--------------------------------------------------*
 HP         https://espace.monbalcon.net/
 Twitter    https://twitter.com/espace_vvv
 マシュマロ  https://marshmallow-qa.com/espace_vvv
*--------------------------------------------------*


*** 各種ファイルについて ***
[]…ディレクトリ

[temp]
    ├ [css]                 ・CSSディレクトリ
    │   └ style.css             ・CSSファイル
    │
    ├ [js]                  ・JavaScriptディレクトリ
    │   └ general.js            ・全ページ共通の動作（スクロール、表示/非表示切り替えなど）
    │
    ├ banner.jpg            ・バナー画像
    │
    ├ readme.txt            ・このファイル
    │
    ├ index.html            ・indexページサンプル
    │
    ├ novel.html            ・小説ページサンプル
    │
    ├ novel_no_header_1.html・小説ページ（ヘッダー無し）サンプル
    ├ novel_no_header_2.html・小説ページ（ヘッダー無し）サンプル
    │
    ├ toc.html              ・目次ページサンプル
    │
    └ top.html              ・コンテンツページサンプル